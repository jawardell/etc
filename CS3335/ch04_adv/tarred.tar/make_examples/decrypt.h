void decrypt(char *);

