#include "cl.h"
#include <stdio.h>
#include <stdlib.h>


typedef struct soldier_type {
	char* name;
	soldier_type next;
} soldier;

int main() {

	soldier* cursor;
	


}




