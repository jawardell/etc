#include <stdio.h>
#include <limits.h>
#include <float.h> //this contains the e constant for scientific notation
int main () {
	puts("C Rocks!");
	printf("CHAR_MIN=%d\n", CHAR_MIN);
	printf("FLT_MAX=%.10e\n", FLT_MAX);
	return 0;
}

