double mean(double list[8]);
