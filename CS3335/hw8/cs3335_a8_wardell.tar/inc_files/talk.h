void talk();
