int getin(double[8]);
