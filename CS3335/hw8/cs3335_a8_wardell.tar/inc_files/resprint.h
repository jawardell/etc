void resprint(double[8], double[8], double, double);
