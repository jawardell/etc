void arrprint(double[8]);
