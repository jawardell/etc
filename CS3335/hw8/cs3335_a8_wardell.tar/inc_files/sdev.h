double sdev(double[8], double);
