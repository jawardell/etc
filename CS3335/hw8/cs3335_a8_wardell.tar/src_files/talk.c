#include "talk.h"

#include <stdio.h>
void talk() {
	puts("\nHello human!\n");
	puts("\nI will make some calculations for you.\n");
	puts("\nPlease enter eight numbers. Thank you!\n");
}
