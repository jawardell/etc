typedef struct {
	const char* face;
	const char* suit;
	int facevalue;
	int suitvalue;
}card;
