void qsort(void*, size_t, size_t, int(*compare)(const void*, const void*));
