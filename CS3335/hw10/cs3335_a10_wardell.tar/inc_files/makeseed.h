void makeseed();
