#include <time.h>
#include "makeseed.h"

void makeseed() {
	srand(time(NULL));
}
