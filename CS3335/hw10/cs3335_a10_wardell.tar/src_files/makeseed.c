#include <time.h>
#include "makeseed.h"
#include <stdlib.h>
void makeseed() {
	srand(time(NULL));
}
