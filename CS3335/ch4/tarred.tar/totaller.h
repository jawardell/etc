float add_with_tax(float);

// short count=0;

