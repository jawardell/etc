#include "retone.h"

int retone() {
	return 1;
}
