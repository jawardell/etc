#include "retzero.h"

int retzero() {
	return 0;
}
