int retzero();
